package com.example.shopping_list.presenter;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.example.shopping_list.сontract.ProductsListContract;

import java.util.ArrayList;

public class ProductsListPresenter implements ProductsListContract.Presenter {

    private ProductsListContract.View view;

    public ProductsListPresenter(ProductsListContract.View view) {
        this.view = view;
    }

    @Override
    public void setProductList(Context context) {
        ArrayList<String> products = new ArrayList<>();
        products.add("Apple");
        products.add("Orange");

        ArrayAdapter<ArrayList> adapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, products);

        view.setList(adapter);
    }
}
