package com.example.shopping_list.model;

import com.example.shopping_list.view.ProductsListFragment;

import java.util.ArrayList;
import java.util.List;

public class ProductsListData {

    private String name;
    private ArrayList<String> productsList;

    public ProductsListData() {
        productsList = new ArrayList<String>();
    }

    public void addProductToList(String product) {
        productsList.add(product);
    }

    public void deleteProductFromList(int id) {
        productsList.remove(id);
    }
}
