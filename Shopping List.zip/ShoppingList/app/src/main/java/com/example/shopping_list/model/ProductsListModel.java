package com.example.shopping_list.model;

import android.app.Activity;
import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.widget.ArrayAdapter;

import com.example.shopping_list.сontract.ProductsListContract;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ProductsListModel implements ProductsListContract.Model {

    private ArrayList<String> products;
    private static final String filename = "products_list.json";
    private FileOutputStream outputStream;

    public boolean isFileCreated(Context context, Activity activity) throws JSONException, FileNotFoundException {

        File directory = context.getFilesDir();
        File file = new File(directory, filename);

        JSONObject jo = new JSONObject();

        // putting data to JSONObject
        jo.put("firstName", "John");
        jo.put("lastName", "Smith");
        jo.put("age", 25);

        // for address data, first create LinkedHashMap
        Map m = new LinkedHashMap(4);
        m.put("streetAddress", "21 2nd Street");
        m.put("city", "New York");
        m.put("state", "NY");
        m.put("postalCode", 10021);

        // putting address to JSONObject
        jo.put("address", m);

        // for phone numbers, first create JSONArray
        JSONArray ja = new JSONArray();

        m = new LinkedHashMap(2);
        m.put("type", "home");
        m.put("number", "212 555-1234");

        // adding map to list
        ja.add(m);

        m = new LinkedHashMap(2);
        m.put("type", "fax");
        m.put("number", "212 555-1234");

        // adding map to list
        ja.add(m);

        // putting phoneNumbers to JSONObject
        jo.put("phoneNumbers", ja);

        // writing JSON to file:"JSONExample.json" in cwd
        PrintWriter pw = new PrintWriter("JSONExample.json");
        pw.write(jo.toJSONString());

        pw.flush();
        pw.close();

        return true;
    }


    public ProductsListModel() {
        products = new ArrayList<>();
        products.add("Apple");
        products.add("Orange");
    }

    @Override
    public void setData(String product) {
        products.add(product);
    }

    @Override
    public void setProductsList(Context context) {
        ArrayAdapter<ArrayList> adapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, products);
    }
}
